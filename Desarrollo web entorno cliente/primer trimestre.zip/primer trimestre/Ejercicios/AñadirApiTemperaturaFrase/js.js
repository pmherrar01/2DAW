//Array para guardar las prendas
let aStock = [];
//variable cont con la que cuento cuantas orendas añado
let cont = 0;
/*
    Utilizo esta variable count para contar cuetnas prendas añado de una vez,
    me refiero de de una vex se presiona 2 veces el boton "enviar" pues se añaden 2 prendas de una vez entonces contaria 2,
    a parte en el metodo mostrar voy poniendo cuantas prendas tiene el array,
    por que no se muy bien a que te refieres con que añadamos el contador que muestre cuantos elementos se han añadido al array
*/
//funcion para añadir una prenda al array
function anadirPrenda() {
  let prendaNueva;

  if (!validarpPrenda()) {
    alert("Por favor, rellena todos los campos");
  } else {
    prendaNueva = datosPrenda(
      Math.floor(Math.random() * 100000),
      document.getElementById("tipoPrenda").value,
      document.getElementById("descripcion").value,
      document.getElementById("precio").value,
      document.getElementById("fechaSalida").value,
      document.querySelector('input[name="tara"]:checked').value === "true"
        ? true
        : false
    );
    if (prendaExiste(prendaNueva)) {
      alert("La prenda ya existe en el stock");
    } else {
      aStock.push(prendaNueva);
      cont++;
    }
  }
}

//funcion para validar que todos los campos esten rellenos
function validarpPrenda() {
  let tipoPrenda = document.getElementById("tipoPrenda").value;
  let descripcion = document.getElementById("descripcion").value;
  let precio = document.getElementById("precio").value;
  let fechaSalida = document.getElementById("fechaSalida").value;
  let tara = document.querySelector('input[name="tara"]:checked');

  if (
    tipoPrenda === "" ||
    descripcion === "" ||
    precio === "" ||
    fechaSalida === "" ||
    tara === null
  ) {
    return false;
  }

  return true;
}
//funcion para crear un objeto prenda que lo retorna
function datosPrenda(
  codigoPrenda,
  tipoPrenda,
  descripcion,
  precio,
  fechaSalida,
  tara
) {
  let prenda = {
    codigoPrenda,
    tipoPrenda,
    descripcion,
    precio,
    fechaSalida,
    tara,
  };

  return prenda;
}

//funcion para odernar el array por precio
function ordenarPrecio() {
  return aStock.sort((a, b) => a.precio - b.precio);
}

//funcion para comprobar si una prenda ya existe en el array
function prendaExiste(prendaBuscar) {
  if (aStock.length === 0) {
    return false;
  } else {
    for (let i = 0; i < aStock.length; i++) {
      if (aStock[i].codigoPrenda === prendaBuscar.codigoPrenda) {
        return true;
      }
    }
  }

  return false;
}

//funcion para borrar una prenda del array
function borrarPrenda() {

  let codigoPrendaABorrar = prompt( mostrarStock(),
    "Introduce el codigo de la prenda a borrar:"
  );

  if (aStock.includes(codigoPrendaABorrar)) {
    alert("La prenda no existe en el stock");
  } else {
    for (let i = 0; i < aStock.length; i++) {
      if (aStock[i].codigoPrenda == codigoPrendaABorrar) {
        aStock.splice(i, 1);
        alert("Prenda borrada correctamente");
        return;
      }
    }
  }
}

//funcion para mostrar
function mostrarStock() {
  let aStockOrdenado = ordenarPrecio();

  let mensaje = `Mostarndo el stock ordenado por precio\n`;

  for (let i = 0; i < aStockOrdenado.length; i++ ) {
    mensaje += `\n Codigo prenda ${aStockOrdenado[i].codigoPrenda}:   ${
      aStockOrdenado[i].tipoPrenda
    } \n Descipcion: ${aStockOrdenado[i].descripcion} \nPrecio: ${
      aStockOrdenado[i].precio
    } \nFecha de salida: ${
      aStockOrdenado[i].fechaSalida
    } \n¿Tiene tara?: ${aStockOrdenado[i].tara}\n`;
  }

  alert(mensaje);

  alert(`Se han añadido ${cont} prendas al stock`);
  cont = 0;
}

const latitude = 39.4765;
const longitude = -6.3722;

fetch(
  `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&hourly=temperature_2m,relative_humidity_2m&timezone=auto&forecast_days=1`
)
  .then((response) => response.json())
  .then((json) => {
    const horaActual = new Date().getHours();
    const datos = json.hourly;
    pintarTemperaturaActual(datos, horaActual);
  });

function pintarTemperaturaActual(datos, horaActual) {
  const container = document.getElementById("container");

  const temperaturaActual = datos.temperature_2m[horaActual + 2];
  const humedadActual = datos.relative_humidity_2m[horaActual + 2];

  container.innerHTML = `
            <div class="card">
                <p>Temperatura en dos horas: ${temperaturaActual}°C</p>
                <p>Humedad relativa en dos horas: ${humedadActual} %</p>
            </div>
        `;
}

fetch(`https://jsonplaceholder.typicode.com/posts`)
  .then((response) => response.json())
  .then((json) => {
    // const aUsuarios = json;
    pintarFrase(json);
  });

function pintarFrase(usuarios) {
  const containerFrase = document.getElementById("frase");

  const usuarioId = Math.floor(Math.random() * 10) + 1;
  let idFrase = Math.floor(Math.random() * 10) + 1 + (usuarioId - 1) * 10;
  let contenidoFrase = "No se ha encontrado nada";

  for (let i = 0; i < usuarios.length; i++) {
    if (usuarios[i].userId === usuarioId && usuarios[i].id === idFrase) {
      contenidoFrase = usuarios[i].body;
      break;
    }
  }

  containerFrase.innerHTML = `
    <div class="card">
    <p>Frase aleatoria : ${contenidoFrase}</p>
    </div>
`;
}
