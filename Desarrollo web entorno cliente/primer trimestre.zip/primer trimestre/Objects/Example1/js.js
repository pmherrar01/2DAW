let ticket = {
    station1 : "station1",
    ensStation : "Caceres",
    price : "34€"
};

console.log("FRom: ", ticket.station1 , " station");
console.log("end: ", ticket.ensStation , " station");
console.log("price: ", ticket.price , " ");

console.log(`From ${ticket.station1} station,  end station ${ticket.ensStation} and price: ${ticket.price}`);

