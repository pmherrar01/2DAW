let verdadero = true;
let num = 9;
let word = "hello";
let y = undefined;
let numBig = 23124134n;


console.log(`${verdadero} [${typeof verdadero}]`, `${num} [${typeof num}]` , `${word} [${typeof word}]`, `${y} [${typeof y}]`, `${numBig} [${typeof numBig}]`);