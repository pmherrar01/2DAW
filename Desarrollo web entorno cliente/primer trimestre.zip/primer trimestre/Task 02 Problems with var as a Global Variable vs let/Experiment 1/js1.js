var username = "Alice"; 
var username = "Bob"; 
console.log(username);