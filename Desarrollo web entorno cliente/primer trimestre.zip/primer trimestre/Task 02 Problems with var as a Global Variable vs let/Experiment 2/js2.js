let age = 20;
let age = 25; 
console.log(age);