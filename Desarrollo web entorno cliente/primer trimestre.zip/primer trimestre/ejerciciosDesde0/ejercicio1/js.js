let nombre = "pablo";
const edad = 20;
let estudio = true;

if (estudio) {
    console.log(nombre + edad + " si estudio");    
}


