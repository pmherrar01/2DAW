let num = Number(prompt("insert number"));
let num2 = Number(prompt("insert number"));

function suma(params1, params2) {
    return params1 + params2
}

let resultado = suma(num, num2);

console.log(resultado);
