let hello = prompt("hello");
console.log("script defer started");
console.log("script defer end");