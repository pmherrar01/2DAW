console.log("script async started");
let hola = prompt("escribe");
console.log("script async end");