let weigth;
let heigth

function funcion1() {

    heigth = prompt("heigth:");

}

function function2() {

    weigth = prompt("weigth:");

}

funcion1();
function2();

console.log(heigth + "," + weigth);  